from django.shortcuts import render, get_object_or_404
from .models import Kategori, Produk

# --- HALAMAN PUBLIK ---
def landing_page(request):
    return render(request, "smartbako/landing_page/beranda.html")

def fitur_view(request):
    return render(request, "smartbako/landing_page/fitur.html")

def produk_publik_view(request):
    produk_list = Produk.objects.all()
    return render(request, "smartbako/landing_page/produk.html", {"produk_list": produk_list})

def tentang_kami_view(request):
    return render(request, "smartbako/landing_page/tentang_kami.html")

def login_view(request):
    return render(request, "smartbako/auth/login.html")

def registrasi_view(request):
    return render(request, "smartbako/auth/register.html")

# --- HALAMAN PENGGUNA ---
def beranda(request):
    produk_terbaru = Produk.objects.select_related("kategori").all()[:8]
    return render(request, "smartbako/panel_pengguna/dashboard.html", {"produk_terbaru": produk_terbaru})

def katalog(request):
    daftar_produk = Produk.objects.select_related("kategori").all()
    daftar_kategori = Kategori.objects.all()

    kata_kunci = request.GET.get("q", "").strip()
    kategori_id = request.GET.get("kategori", "")

    if kata_kunci:
        daftar_produk = daftar_produk.filter(nama__icontains=kata_kunci) | daftar_produk.filter(merek__icontains=kata_kunci)

    if kategori_id.isdigit():
        daftar_produk = daftar_produk.filter(kategori_id=int(kategori_id))

    context = {
        "produk_list": daftar_produk.distinct(),
        "kategori_list": daftar_kategori,
        "kata_kunci": kata_kunci,
        "kategori_terpilih": kategori_id,
    }
    return render(request, "smartbako/panel_pengguna/katalog.html", context)

def detail_produk(request, produk_id):
    produk = get_object_or_404(Produk, pk=produk_id)
    return render(request, "smartbako/panel_pengguna/detail_produk.html", {"produk": produk})

def rekomendasi(request):
    return render(request, "smartbako/panel_pengguna/rekomendasi.html")

# --- HALAMAN ADMIN KUSTOM ---
def admin_dashboard(request):
    return render(request, "smartbako/panel_admin/dashboard.html")

def admin_kelola_produk(request):
    produk_list = Produk.objects.all()
    return render(request, "smartbako/panel_admin/kelola_produk/daftar.html", {"produk_list": produk_list})